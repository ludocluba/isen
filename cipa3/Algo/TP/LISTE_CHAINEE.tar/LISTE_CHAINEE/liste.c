#include <stdio.h>
#include <stdlib.h>
#include "outils.h"

#define N 4

int main() {

    int tab[N] = {0, 1, 2, 3};
    int i; 

    struct element* liste;

    printf("===================================\n\n");
    printf("        Les listes chainées\n");
    printf("===================================\n\n");

    //On insère 1 élément
    printf("Initialisation: \n");
    liste = initialisation(tab[0]);
    //On affiche la liste 
    affiche(liste);

    printf("\nInsertion de 3 éléments: \n");
    //Puis 3 autres
    for (i=1; i<N; i++) {
        liste = insertion(liste, tab[i]);
    }
    //On affiche la liste 
    affiche(liste);

    printf("\nSuppression d'1 élément au début: \n");
    //On supprime le premier élément
    liste = suppression(liste);
    //On affiche la liste
    affiche(liste);
    //on supprime encore le premier élément
    printf("\nSuppression d'1 élément au début: \n");
    liste = suppression(liste);
    affiche(liste);

}