#include "outils.h"
#include <stdlib.h>
#include <stdio.h>

// Ecrire une fonction qui initialise la liste avec un élément :
struct element* initialisation(int val) {
    struct element* elt = malloc(sizeof(struct element));
    elt->nombre = val;
    elt->suivant = NULL;
    return elt;
}

// Ecrire une fonction qui ajoute un élément au début de la liste :
struct  element * insertion(struct  element *liste, int nvNombre){
    struct element* elt = initialisation(nvNombre);
    elt->suivant = liste;
    return elt;
}

// Ecrire une fonction qui affiche tous les éléments de la liste
void affiche(struct element* liste){
    if (liste != NULL) {
        printf("\tnombre = %d\n", liste->nombre);
        if (liste->suivant != NULL) {
            affiche(liste->suivant);
        }
        else {
            printf("===================================\n\n");
        }
    }
}

// Ecrire une fonction qui supprime le premier élément dans la liste
struct  element * suppression(struct  element* liste){
    struct element* res = liste->suivant;
    free(liste);
    return res;
}











