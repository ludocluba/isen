struct element
{
    int nombre;
    struct element *suivant;
};

// Ecrire une fonction qui initialise la liste avec un élément :
struct element* initialisation(int val);

// Ecrire une fonction qui ajoute un élément au début de la liste :
struct element* insertion(struct  element* liste, int nvNombre);

// Ecrire une fonction qui affiche tous les éléments de la liste
void affiche(struct element* liste);

// Ecrire une fonction qui supprime un élément dans la liste
struct  element * suppression(struct  element* liste);
