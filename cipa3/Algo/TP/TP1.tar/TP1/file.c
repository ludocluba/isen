#include <stdio.h>
#include <stdlib.h>

int main() {

  FILE* file;
  char word[1000];
  file = fopen("./test.txt", "w");
  if (file == NULL) {
    printf("probleme d'ouverture du fichier\n");
    return EXIT_FAILURE;
  }
  fprintf(file,"Ceci est un test\n");
  fclose(file);

  file = fopen("./test.txt", "r");
  if (file == NULL) {
    printf("probleme d'ouverture du fichier\n");
    return EXIT_FAILURE;
  }
  fscanf(file,"%s", word);
  fclose(file);

  printf("%s\n", word);

  return EXIT_SUCCESS;
}
