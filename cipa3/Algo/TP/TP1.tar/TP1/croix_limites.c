//fichier croix.c
#include <stdio.h>
#include <stdlib.h>
#include "limites.h"

//A modifier
void croixSaintAndre(int L, int H) {

    int i, j;

    printf("\n");
    //Première ligne
    i=0;
    while (i<L && i<LMAX) {
        printf("*");
        i++;
    }
    printf("\n");

    //Interieur du rectangle
    i=1;
    while ((i<H-1) && (i<HMAX)) {
        printf("*");
        j=1;
        while ((j<L-1) && (j<LMAX)) {
          if ((i==j) || (j==L-1-i)) {
              printf("*");
            }
            else printf(" ");
            j++;
        }
        if (j<LMAX) {
          printf("*");
        }
        printf("\n");
        i++;
    }

    //Derniere ligne
    if (i<HMAX) {
      i=0;
      while (i<L && i<LMAX) {
          printf("*");
          i++;
        }
        printf("\n");
      }
}
