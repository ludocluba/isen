//fichier rect_limites.c
#include <stdio.h>
#include "limites.h"

//A modifier
void rectangle(int L, int H) {

    int i, j;

    printf("\n");
    i=0;
    while (i<L && i<LMAX) {
        printf("*");
        i++;
    }
    printf("\n");
    i=1;
    while ((i<H-1) && (i<HMAX)) {
        printf("*");
        j=1;
        while ((j<L-1) && (j<LMAX)) {
            printf(" ");
            j++;
        }
        if (j<LMAX) {
          printf("*");
        }
        printf("\n");
        i++;
    }
    if (i<HMAX) {
      i=0;
      while (i<L && i<LMAX) {
          printf("*");
          i++;
        }
        printf("\n");
      }
}
