//fichier pp.c
#include <stdio.h>
#include <stdlib.h>
#include "rect.h"


int main() {
  int L,H;

	printf("Donnez la largeur: ");
	scanf("%d", &L);

	printf("Donnez la hauteur: ");
	scanf("%d", &H);

	rectangle(L,H);

  printf("\n================\n");

  croixSaintAndre(L,H);
	return EXIT_SUCCESS;
}
