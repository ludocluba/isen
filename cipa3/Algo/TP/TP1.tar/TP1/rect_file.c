//fichier rect.c
#include <stdio.h>
#include <stdlib.h>

//A modifier
void rectangle(int L, int H) {

    int i, j;
    FILE* file;

    file = fopen("./rect.txt", "w");
    if (file == NULL) {
      printf("probleme d'ouverture du fichier\n");
    }

    fprintf(file,"\n");
    for (i=1; i<=L; i++) {
        fprintf(file,"*");
    }
    fprintf(file,"\n");
    for (i=2; i<H; i++) {
        fprintf(file,"*");
        for (j=2; j<L; j++) {
            fprintf(file," ");
        }
        fprintf(file,"*");
        fprintf(file,"\n");
    }
    for (i=1; i<=L; i++) {
        fprintf(file,"*");
    }
    fprintf(file,"\n");

    fclose(file);
}
