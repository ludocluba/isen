//fichier croix.c
#include <stdio.h>
#include <stdlib.h>

//A modifier
void croixSaintAndre(int L, int H) {

    int i, j;

    printf("\n");
    //Première ligne
    for (i=0; i<L; i++) {
        printf("*");
    }
    printf("\n");

    //Interieur du rectangle
    for (i=1; i<H-1; i++) {
        printf("*");
        for (j=1; j<L-1; j++) {
          if ((i==j) || (j==L-1-i)) {
              printf("*");
            }
            else printf(" ");
        }
        printf("*");
        printf("\n");
    }

    //Derniere ligne
    for (i=0; i<L; i++) {
        printf("*");
    }
    printf("\n");
}
