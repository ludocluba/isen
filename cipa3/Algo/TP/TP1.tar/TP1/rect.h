//fichier rect.h
void rectangle(int L, int H);
void croixSaintAndre(int L, int H);
