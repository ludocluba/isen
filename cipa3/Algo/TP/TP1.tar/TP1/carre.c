#include <stdio.h>
#include <stdlib.h>

int main() {

    int t;
    int i,j;
    printf("Donnez la taille du carre : ");
    scanf("%d",&t);
    printf("\n");
    for (i=1; i<=t; i++) {
        printf("*");
    }
    printf("\n");
    for (i=2; i<t; i++) {
        printf("*");
        for (j=2; j<t; j++) {
            printf(" ");
        }
        printf("*");
        printf("\n");
    }
    for (i=1; i<=t; i++) {
        printf("*");
    }
    printf("\n");
    return EXIT_SUCCESS;
}
