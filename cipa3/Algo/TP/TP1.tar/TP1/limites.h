//fichier limites.h
#define LMAX 20
#define HMAX 5
