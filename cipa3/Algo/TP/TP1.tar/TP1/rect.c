//fichier rect.c
#include <stdio.h>
#include <stdlib.h>

//A modifier
void rectangle(int L, int H) {

    int i, j;

    printf("\n");
    for (i=1; i<=L; i++) {
        printf("*");
    }
    printf("\n");
    for (i=2; i<H; i++) {
        printf("*");
        for (j=2; j<L; j++) {
            printf(" ");
        }
        printf("*");
        printf("\n");
    }
    for (i=1; i<=L; i++) {
        printf("*");
    }
    printf("\n");
}


