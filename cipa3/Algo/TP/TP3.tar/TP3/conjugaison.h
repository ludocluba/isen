#define N 100
char* conjugue(const char* pronom,const char* verbe);