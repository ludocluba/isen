#define N 50

char* conjugue(const char* pronom, const char* verbe);
int verifPronom(const char* pronom);
int verifVerbe(const char* verbe);
