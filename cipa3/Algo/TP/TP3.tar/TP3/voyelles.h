#define N 50

int nombreVoyelles(const char chaine[N]);
void recupVoyelles(const char chaine[N], char voyelles[N]);
int verifVoyelle(const char c);
