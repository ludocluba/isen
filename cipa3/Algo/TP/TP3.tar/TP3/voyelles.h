#define N 50

int nombreVoyelles(const char chaine[50]);
int verifVoyelle(const char c) ;
void recupVoyelles(const char chaine[N], char voyelles[N]);
char* recupVoyelles2(const char chaine[N]);