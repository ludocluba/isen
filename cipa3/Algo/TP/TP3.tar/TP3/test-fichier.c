#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>


int main() {
    char line[100];
    FILE* file;
    file = fopen("fichier.txt", "r+");
    while(1) {
        fgets(line, 100, file);
        printf("%s", line);
        sleep(1);
    }
}