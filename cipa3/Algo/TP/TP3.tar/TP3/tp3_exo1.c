#include <stdio.h>
#include <stdlib.h>
#include "voyelles.h"

int main() {

  char chaine[N];
  char voyelles[N];

  printf("Entrez une chaîne de caractères (<50) \n");
  fgets(chaine, N, stdin);

  printf("Nombre de voyelles: %d\n", nombreVoyelles(chaine));
  recupVoyelles(chaine, voyelles);
  printf("Voyelles: %s\n", voyelles);

  return EXIT_SUCCESS;
}
