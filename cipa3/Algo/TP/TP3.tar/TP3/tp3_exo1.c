#include <stdio.h>
#include <stdlib.h>
#include "voyelles.h"

int main() {

    int nbVoyelles = 0;
    char chaine[N];
    char voyelles[N] = {0};
    char* voyelles2;

    printf("Entrer la chaine de caractères (<50)\n");
    //Récupération de la chaine de caractères
    fgets(chaine, N, stdin);
    printf("%s\n", chaine);

    nbVoyelles = nombreVoyelles(chaine);
    printf("Nombre de voyelles: %d\n", nbVoyelles);

    recupVoyelles(chaine, voyelles);
    printf("Voyelles: %s\n", voyelles);

    voyelles2 = recupVoyelles2(chaine);
    printf("Voyelles: %s\n", voyelles2);
    free(voyelles2);
    
}