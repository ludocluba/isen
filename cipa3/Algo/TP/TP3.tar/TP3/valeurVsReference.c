#include <stdio.h>

void passageParValeur(int a) {
    a = 10;
}

void passageParReference(int* a) {
    *a = 20;
}

int main() {

    int a = 0;
    passageParValeur(a);
    printf("a = %d\n", a);

    passageParReference(&a);
    printf("a = %d\n", a);

}