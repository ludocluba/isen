#include <stdio.h>
#include <stdlib.h>
#include "conjugaison.h"

int main() {

  char pronom[N] = "jeu";
  char verbe[N] = "chanter";
  char *conjug;

  printf("Veuillez saisir un pronom\n");
  scanf("%s", pronom);
  printf("Veuillez saisir un verbe\n");
  scanf("%s", verbe);

  conjug = conjugue(pronom, verbe);
  printf("%s %s\n",pronom, conjug);

  free(conjug);

  return EXIT_SUCCESS;
}
