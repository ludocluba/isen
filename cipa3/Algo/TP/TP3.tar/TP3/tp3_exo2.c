#include <stdio.h>
#include <stdlib.h>
#include "conjugaison.h"
int main() {


    char pronom[N];
    char verbe[N];
    char* verbeConjugue;   

    printf("Veuillez saisir un pronom\n");
    //Récupération de la chaine de caractères
    scanf("%s", pronom);

    printf("Veuiller saisir un verbe du 1er groupe\n");
    //Récupération de la chaine de caractères
    scanf("%s", verbe);
 
    verbeConjugue = conjugue(pronom, verbe); 

    if (verbeConjugue != NULL)
        printf("%s %s\n", pronom, verbeConjugue);
    else printf("RETURN NULL\n");


}