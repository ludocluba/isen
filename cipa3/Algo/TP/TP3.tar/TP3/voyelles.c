#include "voyelles.h"
#include <string.h>
#include <stdlib.h>

int nombreVoyelles(const char chaine[N]) {
    int i;
    int nb = 0;

    for (i=0; i < strlen(chaine); i++) {
        if (verifVoyelle(chaine[i]) == 0) {
            nb++;
        }
    }
    return nb;
}

int verifVoyelle(const char c) {
    switch (c) {
        case 'a':
        case 'e':
        case 'i':
        case 'o':
        case 'u':
        case 'y': return 0;
        default : return 1;
    }
}

void recupVoyelles(const char chaine[N], char voyelles[N]) {
    int i;
    int j=0;
    for (i=0; i < strlen(chaine); i++) {
        if (verifVoyelle(chaine[i]) == 0) {
            voyelles[j++] = chaine[i];
        }
    }
    voyelles[j] = '\0';
}


char* recupVoyelles2(const char chaine[N]) {
    int i, j=0;
    char* voyelles = malloc(N*sizeof(char));
    for (i=0; i < strlen(chaine); i++) {
        if (verifVoyelle(chaine[i]) == 0) {
            voyelles[j++] = chaine[i];
        }
    }
    voyelles[j] = '\0';
    return voyelles;
}













