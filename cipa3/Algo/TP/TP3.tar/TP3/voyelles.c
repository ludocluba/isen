#include "voyelles.h"

int nombreVoyelles(const char chaine[N]) {

  int i;
  int nb=0;

  for (i=0; i<N; i++) {
    if (verifVoyelle(chaine[i]) == 0) {
      nb++;
    }
  }

  return nb;
}
void recupVoyelles(const char chaine[N], char voyelles[N]) {

  int i, j;
  j=0;

  for (i=0; i<N; i++) {
    if (verifVoyelle(chaine[i]) == 0) {
      voyelles[j] = chaine[i];
      j++;
    }
  }
  voyelles[j]='\0';
}


int verifVoyelle(const char c) {
  char c1;
  c1=c;
  //Passage en minuscule
  // A:65; Z:90; a:97; z:122
  // +32 => permet de passer en minuscule
  if (c1<=90) {
    c1 += 32;
  }
  switch(c1) {
    case 'a':
    case 'e':
    case 'i':
    case 'o':
    case 'u':
    case 'y': return 0;
    default: return 1;
  }
}
