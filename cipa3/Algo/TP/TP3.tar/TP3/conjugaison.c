#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "conjugaison.h"

char* conjugue(const char* pronom,const char* verbe) {
    int taille;
    char terminaison[4];
    char* debutVerbe;


    if ((strcmp(pronom,"je") !=0) &&
        (strcmp(pronom,"tu") !=0) &&
        (strcmp(pronom,"elle") !=0) &&
        (strcmp(pronom,"nous") !=0) &&
        (strcmp(pronom,"vous") !=0) &&
        (strcmp(pronom,"elles") !=0))
    {
        printf("Erreur de pronom\n");
        return NULL;
    }
    taille = strlen(verbe);
    if ((taille < 4) || verbe[taille-1] != 'r' || verbe[taille-2] != 'e') {
        printf("Erreur de verbe\n");
        return NULL;
    }

    if (strcmp(pronom,"je")==0 || strcmp(pronom,"elle")==0 ) {
        strcpy(terminaison,"e");
    }
    else if (strcmp(pronom,"tu")==0) {
        strcpy(terminaison,"es");
    }
    else if (strcmp(pronom,"nous")==0) {
        strcpy(terminaison,"ons");
    }
    else if (strcmp(pronom,"vous")==0) {
        strcpy(terminaison,"ez");
    }
    else if (strcmp(pronom,"elles")==0) {
        strcpy(terminaison,"ent");
    }

    debutVerbe = malloc(sizeof(char)*taille);
    strcpy(debutVerbe, verbe);
    debutVerbe[taille - 2] = '\0';
    strcat(debutVerbe, terminaison);

    printf("dans la fonction: %s\n", debutVerbe);

    return debutVerbe;
}









