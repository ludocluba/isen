#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "conjugaison.h"

char* conjugue(const char* pronom,const char* verbe) {

  int result;
  char* conjugue;
  if (verifPronom(pronom) != 0) {
    printf("le pronom n'est pas correct! \n");
    return NULL;
  }
  result = verifVerbe(verbe);
  if (result == 1){
    printf("le verbe ne se termine pas par er \n");
    return NULL;
  }
  else if (result == 2){
    printf("le verbe n'est pas de taille 4 \n");
    return NULL;
  }
  conjugue = malloc(N*sizeof(char));

  strncpy(conjugue, verbe, strlen(verbe)-2);

  if ((strcmp(pronom, "je") == 0) ||
     (strcmp(pronom, "il") == 0) ||
     (strcmp(pronom, "elle") == 0)) {
    strcat(conjugue,"e");
  }
  else if (strcmp(pronom, "tu") == 0) {
    strcat(conjugue,"es");
  }
  else if (strcmp(pronom, "nous") == 0) {
    strcat(conjugue,"ons");
  }
  else if (strcmp(pronom, "vous")  == 0) {
    strcat(conjugue,"ez");
  }
  else if ((strcmp(pronom, "ils")  == 0) ||
           (strcmp(pronom, "elles") == 0)) {
    strcat(conjugue,"ent");
  }
  return conjugue;
}

int verifPronom(const char* pronom) {
  if ( (strcmp (pronom, "je") == 0 ) ||
       (strcmp (pronom, "tu") == 0) ||
       (strcmp (pronom, "il") == 0) ||
       (strcmp (pronom, "elle") == 0) ||
       (strcmp (pronom, "nous") == 0) ||
       (strcmp (pronom, "vous") == 0) ||
       (strcmp (pronom, "ils") == 0) ||
       (strcmp (pronom, "elles") == 0))
       return 0;
  else return 1;
}


int verifVerbe(const char* verbe) {
  if (strlen(verbe) > 4) {
    if ((verbe[strlen(verbe)-1] == 'r') &&
        (verbe[strlen(verbe)-2] == 'e')) {
          return 0;
    }
    else return 1;
  }
  else return 2;
}
