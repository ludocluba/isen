#include "init.h"

int main() {
	int* tab1;
	int tab2[100];

	tab1 = init_tab1();
	init_tab2(tab2);

    free(tab1);
}
