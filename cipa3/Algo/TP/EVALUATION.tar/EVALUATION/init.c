#include <stdlib.h>

int* init_tab1() {
    int i;
    int* result = malloc(100*sizeof(int));
    for (i=0; i<100; i++) {
        result[i] = -1;
    }
    return result;
}

void init_tab2(int tab[100]) {
    int i;
    for (i=0; i<100; i++) {
        tab[i] = -1;
    }
}

