#include "init.h"
#include <stdio.h>
#include <stdlib.h>


int main() {
	int temp[14]={7,-10,13,8,4,-7,-12,-3,3,-9,6,-1,-6,7};
	int i=0, size=14;
	int close_zero;


	close_zero = temp[0];
	for (i=1; i<size; i++) {
		if (close_zero*close_zero < temp[i]*temp[i]) ||
		   ((close_zero*close_zero == temp[i]*temp[i]) &&
			      close_zero < temp[i])
			close_zero = temp[i];
		} 
	}
	printf("Température trouvée: %d\n", close_zero);
	
}
