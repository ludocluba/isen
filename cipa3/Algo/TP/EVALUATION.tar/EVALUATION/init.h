int* init_tab1();
void init_tab2(int tab[100]);