#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

#define ESSAI 10
#define MIN 1
#define MAX 1000

int main() {
	
    int nombre=0, val=0, indice=0;
	srand(time(NULL));

	//Initialisation
    nombre = MIN + rand() % (MAX+1 - MIN);
	
    
    printf("1er essai: ");
    scanf("%d", &val);
    indice++;

    //
    if (val == nombre) {
        printf("Whouaaa!!!");
        return EXIT_SUCCESS;
    }
    do {
        if (abs(val-nombre) <= 10) {
            printf("*");
        } 
        else if (abs(val-nombre) <= 100) {
            printf("**");
        }  
        else if (abs(val-nombre) > 100) {
            printf("***");
        }  
        printf("%deme essai: ", indice);
        scanf("%d", &val);
        indice++;
    } while ((indice <= 10) && (val != nombre));

    if (val == nombre) {
        printf("Trouvé : nb essai=%d", indice);
        return EXIT_SUCCESS;
    } else {
        printf("Perdu !!! Le nombre était: %d", nombre);
        return EXIT_SUCCESS;
    }
}
