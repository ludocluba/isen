#include "init.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define N 100
#define MIN 3000
#define MAX 8000

int main() {
	
	int tab[N];
	int i, max, indice;
	srand(time(NULL));

	//Initialisation
	for (i=0; i<N; i++) {
		tab[i] = MIN + rand() % (MAX+1 - MIN);
	}

	//Recherche
	max=tab[0];
	indice = 0;
	for (i=0; i<N; i++) {
		if (max < tab[i] ) {
			max = tab[i];
			indice = i;
		}
	}

	printf("L'indice est : %d\n", indice);
}
