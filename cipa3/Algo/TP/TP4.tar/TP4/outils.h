struct noeud
{
    char *texte;
    int numero;
    struct noeud *filsG;
    struct noeud *filsD;
};

struct noeud* constructArbre(int numero, int* tabNums, char** tabTextes,int nbTextes);
void parcours(struct noeud* racine);