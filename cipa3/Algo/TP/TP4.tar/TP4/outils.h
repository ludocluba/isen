struct noeud* constructArbre(int numero, int* tabNums, char** tabTextes,int nbTextes);
