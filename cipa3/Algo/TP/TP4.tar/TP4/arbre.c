#include <stdio.h>
#include <stdlib.h>
#include "outils.h"


int main()
{
    char *tabTextes[19] = {"Avez-vous mal a la tete ?",
                           "Avez-vous de la fievre ?",
                           "Avez-vous mal au ventre ?",
                           "Avez-vous mal a la gorge ?",
                           "Souffrez-vous de vomissements ?",
                           "Evitez donc les grands repas !",
                           "Avez-vous des nausees ?",
                           "Vous devriez arreter de fumer !",
                           "Allez vous coucher...",
                           "Cessez de boire une bonne fois pour toute !",
                           "Un bon cachet d’aspirine et puis ça ira...",
                           "Seriez-vous une femme ?",
                           "Avez-vous consulte votre horoscope ?",
                           "Avez-vous des vertiges ?",
                           "Sans-doute mangez-vous trop vite !",
                           "Votre astrologue aura peut-etre de meilleurs conseils a vous donner.",
                           "Vous devriez consulter un bon psychiatre !",
                           "Vous etes peut-etre enceinte...",
                           "Quelques jours de conges et puis..."};

    int tabNums[19] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 14, 15, 28, 29, 30, 31, 56, 57};
    struct noeud* arbre;

    arbre = constructArbre(1,tabNums,tabTextes,19);

    parcours(arbre);
}












