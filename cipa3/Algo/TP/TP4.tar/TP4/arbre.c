#include <stdio.h>
#include <stdlib.h>

struct noeud
{
    char *texte;
    int numero;
    struct noeud *filsG;
    struct noeud *filsD;
};

int main()
{
    char *tabTextes[19] = {"Avez-vous mal a la tete ?",
                           "Avez-vous de la fievre ?",
                           "Avez-vous mal au ventre ?",
                           "Avez-vous mal a la gorge ?",
                           "Souffrez-vous de vomissements ?",
                           "Evitez donc les grands repas !",
                           "Avez-vous des nausees ?",
                           "Vous devriez arreter de fumer !",
                           "Allez vous coucher...",
                           "Cessez de boire une bonne fois pour toute !",
                           "Un bon cachet d’aspirine et puis ça ira...",
                           "Seriez-vous une femme ?",
                           "Avez-vous consulte votre horoscope ?",
                           "Avez-vous des vertiges ?",
                           "Sans-doute mangez-vous trop vite !",
                           "Votre astrologue aura peut-etre de meilleurs conseils a vous donner.",
                           "Vous devriez consulter un bon psychiatre !",
                           "Vous etes peut-etre enceinte...",
                           "Quelques jours de conges et puis..."};

    int tabNums[19] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 14, 15, 28, 29, 30, 31, 56, 57};
    struct noeud n1;
    struct noeud n2;

    n1.texte = tabTextes[0];
    n1.numero = tabNums[0];
    n1.filsG = &n2;

    n2.texte = tabTextes[1];
    n2.numero = tabNums[1];

    printf("Le texte est : %s\n", n1.texte);
    printf("Le numéro est : %d\n", n1.numero);
}












