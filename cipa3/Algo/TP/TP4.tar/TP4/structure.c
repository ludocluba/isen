#include <stdio.h>
#include <stdlib.h>

struct time {
    int hour;
    int min;
    int sec;
};

int main() {
    struct time t1;
    struct time* t2;
    int* p;
    int i;
    int j;
    int* p1;
    int* p2;
    printf("l'adresse de i: %0X adresse j: %0X \n", &i, &j);
    printf("l'adresse de p1: %0X adresse p2: %0X \n", &p1, &p2);

    printf("taille en mémoire d'un entier %ld\n", sizeof(int));
    printf("taille en mémoire d'une structure time %ld\n", sizeof(struct time));
    printf("taille en mémoire de struct time* %ld\n", sizeof(struct time*));
    printf("taille en mémoire d'un int* %ld\n", sizeof(int*));

    t1.hour = 14;
    t1.min = 56;
    t1.sec = 12;
    printf("heure: %d:%d:%d\n", t1.hour, t1.min, t1.sec);

    t2 = malloc(sizeof(struct time));
    t2->hour = 12;
    t2->min = 0;
    t2->sec = 0;
    printf("heure: %d:%d:%d\n", t2->hour, t2->min, t2->sec);
    free(t2);
}
