#include <stdio.h>

void recursif(int i) {
    printf("debut fonction: i=%d\n", i);
    if (i>=0) {
        printf("\ti = %d\n", i);
        recursif(i-1);
    }
    printf("fin fonction: i=%d\n", i);
}

int main() {
    recursif(N);
}