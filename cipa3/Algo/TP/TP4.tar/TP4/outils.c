#include <stdlib.h>
#include <stdio.h>
#include "outils.h"

struct noeud *constructArbre(int numero, int *tabNums, char **tabTextes, int nbTextes)
{
    int i;

    // Verification de l'existence de numéro
    for (i = 0; i < 19; i++)
    {
        if (tabNums[i] == numero)
            break;
    }
    // Si il n'existe pas on renvoie NULL
    if (i == 19)
        return NULL;

    // On remplit la structure
    struct noeud *arbre = malloc(sizeof(struct noeud));
    arbre->texte = tabTextes[i];
    arbre->numero = numero;
    arbre->filsG = constructArbre(2 * numero, tabNums, tabTextes, 19);
    ;
    arbre->filsD = constructArbre(2 * numero + 1, tabNums, tabTextes, 19);
    ;
}

void parcours(struct noeud *racine)
{
    char rep[1];

    if (racine != NULL)
    {
        printf("%s\n", racine->texte);
        if ((racine->filsG != NULL) &&
            (racine->filsD != NULL))
        {
            scanf("%s", rep);
            if (rep[0] == 'o')
            {
                parcours(racine->filsG);
            }
            else
            {
                parcours(racine->filsD);
            }
        }
    }
}

void afficheArbre(struct noeud *racine)
{
}