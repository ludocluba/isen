struct noeud* constructArbre(int numero, int* tabNums, char** tabTextes,int nbTextes){
    int i;

    for (i=0; i<19; i++) {
        if (tabNums[i] == numero)
            break;
    }

    if (i==19)
        return NULL;

    struct noeud* arbre = malloc(sizeof(struct noeud));
    arbre->texte = tabTextes[i];
    arbre->numero = numero;
    arbre->filsG = NULL;
    arbre->filsD = NULL;
}











void afficheArbre(struct noeud* racine) {

}