#include <stdio.h>
#include <stdlib.h>

float moyenne() {

  int nb;
  int i=0;
  float somme = 0;

  printf("Veuillez entrer des nombres (un nombre \
négatif indiquera la fin) \n");

  do {
    scanf("%d", &nb);
    if (nb >= 0) {
      somme += nb;
      i++;
    }
  } while(nb >= 0);

  if (i==0)
   return 0;

  return somme/i;
}
