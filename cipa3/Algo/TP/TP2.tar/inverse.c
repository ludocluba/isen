#include <stdio.h>
#include <stdlib.h>

#define N 100

int inverse() {

  int nb;
  int tab[N];
  int i=0,j=0;

  printf("Veuillez entrer des nombres (un nombre \
négatif indiquera la fin) \n");

  do {
    scanf("%d", &nb);
    if (nb >= 0) {
      tab[i] = nb;
      i++;
    }
  } while(nb >= 0);

  if (i == 0) {
    printf("Aucun élément dans le tableau\n");
    return 1;
  }

  for (j=i-1; j>=0; j--) {
    printf("tab[%d]=%d\n", j, tab[j]);
  }
  return 0;
}
