#include <stdio.h>
#include <stdlib.h>
#include "matrice.h"
#include <time.h>

int main() {
  int mat1[M][N];
  int mat2[M][N];
  int mat3[M][N];
  srand(time(NULL));
  initMat(mat1);
  initMat(mat2);
  
  afficheMat(mat1);
  afficheMat(mat2);
  addMat(mat1, mat2, mat3);
  afficheMat(mat3);
  multMat(mat1, mat2, mat3);
  afficheMat(mat3);

}
