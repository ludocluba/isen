#include <stdio.h>
#include <stdlib.h>
#include "suite.h"
#include "matrice.h"


int main() {
  int tab1[NM];
  int tab2[NM];
  int tab3[NM];

  initMat(tab1);
  initMat(tab2);
  //addMat(tab1,tab2,tab3);
  multMat(tab1,tab2,tab3);
  afficheMat(tab3);

  return EXIT_SUCCESS;
}
