#include <stdio.h>
#include "matrice.h"

void afficheMat(const int tab[NM]) {
  int i,j;
  for (i=0; i<N; i++) {
    for (j = 0; j < M; j++) {
      printf("%03d\t", tab[i*N+j]);
    }
    printf("\n");
  }
}
void addMat(const int tab1[NM],
            const int tab2[NM],
            int tab3[NM]) {
  int i,j;
  for (i=0; i<N; i++) {
    for (j = 0; j < M; j++) {
      tab3[i*N+j] = tab1[i*N+j] + tab2[i*N+j];
    }
  }
}

void multMat(const int tab1[NM],
            const int tab2[NM],
            int tab3[NM]) {
  int i,j, k;
  for (i=0; i<N; i++) {
    for (j = 0; j < M; j++) {
      //initialisation de tab3[i,j]
      tab3[i*N+j] = 0;
      for (k = 0; k < M; k++) {
        tab3[i*N+j] += tab1[i*N+k] * tab2[k*N+j];
      }
    }
  }
}
void initMat(int tab[NM]) {
  int i,j;
  for (i=0; i<N; i++) {
    for (j = 0; j < M; j++) {
      tab[i*N+j]=i*N+j;
    }
  }
}
