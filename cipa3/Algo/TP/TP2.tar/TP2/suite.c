#include <stdio.h>
#define N 100
void moyenneSuite()
{
  int x = 0;
  float somme = 0;
  int nbNombre = 0;

  do {
    printf("Entrez un nombre positif ou nul : \n");
    scanf("%d", &x);
    if (x>=0) {
      somme += x;
      nbNombre ++;
    }
  } while (x >= 0);

  printf("Moyenne: %f \n", somme/nbNombre);
}

void inverseSuite()
{
  int x=0;
  int i=0;
  int nbNombre = 0;
  int tab[N];
  do {
    printf("Entrez un nombre positif ou nul: \n");
    scanf("%d",&x);

    if (x >= 0) {
      tab[i] = x;
      i++;
    }

  } while (x>=0);
  nbNombre = i;

  for (i = nbNombre-1; i >= 0; i--) {
    printf("%d;", tab[i]);
  }
  printf("\n");
}
