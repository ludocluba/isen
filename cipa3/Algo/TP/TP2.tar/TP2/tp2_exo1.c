#include <stdio.h>
#include <stdlib.h>
#include "suite.h"

int main() {

  moyenneSuite();
  inverseSuite();

  return EXIT_SUCCESS;
}
