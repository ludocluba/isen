#define NM 16
#define N 4
#define M 4

void afficheMat(const int tab[NM]);
void initMat(int tab[NM]);
void addMat(const int tab1[NM],
            const int tab2[NM],
            int tab3[NM]);
void multMat(const int tab1[NM],
             const int tab2[NM],
             int tab3[NM]);
