void moyenneSuite();
void inverseSuite();
