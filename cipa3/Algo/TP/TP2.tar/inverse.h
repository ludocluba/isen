float inverse();
