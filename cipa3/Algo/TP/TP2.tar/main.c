#include <stdio.h>
#include <stdlib.h>
#include "moyenne.h"
#include "inverse.h"

int main() {
  inverse();
  // printf("Moyenne : %.2f", moyenne());
}
