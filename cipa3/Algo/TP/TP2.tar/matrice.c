#include <stdio.h>
#include <stdlib.h>
#include "matrice.h"

void initMat(int mat[M][N]) {
  int i=0, j=0;
  for (i=0; i<N; i++) {
    for (j=0; j<M; j++) {
      mat[i][j]=rand()%101;
    }
  }
}
void afficheMat(const int mat[M][N]) {
  int i=0, j=0;
  for (i=0; i<N; i++) {
    for (j=0; j<M; j++) {
      printf("%d\t",mat[i][j]);
    }
    printf("\n");
  }
  printf("\n");
}

void addMat(const int mat1[M][N],
            const int mat2[M][N],
            int mat3[M][N]) {
  int i=0, j=0;
  for (i=0; i<N; i++) {
    for (j=0; j<M; j++) {
      mat3[i][j] = mat1[i][j]+mat2[i][j];
    }
  }
}

void multMat(const int mat1[M][N],
            const int mat2[M][N],
            int mat3[M][N]) {
  int i=0, j=0, k=0;
  for (i=0; i<N; i++) {
    for (j=0; j<M; j++) {
      mat3[i][j] = 0;
      for (k=0; k<M; k++) {
        mat3[i][j] += mat1[i][k]*mat2[k][j];
      }
    }
  }
}









