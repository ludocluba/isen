float moyenne();
