#define M 4
#define N 4

void initMat(int mat[M][N]);
void afficheMat(const int mat[M][N]);
void addMat(const int mat1[M][N],
            const int mat2[M][N],
            int mat3[M][N]);
void multMat(const int mat1[M][N],
            const int mat2[M][N],
            int mat3[M][N]);